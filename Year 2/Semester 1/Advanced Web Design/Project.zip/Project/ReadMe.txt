Hi Gary,

Im deslexic and sorry if my writing isnt the greatest. :)

