
/**
 * Write a description of class myex here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class outOfRange extends Exception 
{

   outOfRange (String message)
    {
	super (message);	
	}
}
