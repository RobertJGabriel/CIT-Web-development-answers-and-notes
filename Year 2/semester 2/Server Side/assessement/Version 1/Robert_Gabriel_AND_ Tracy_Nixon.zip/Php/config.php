<?php

//Server Connection Details 

$host = '157.190.64.130';
$username = 'R00102430';
$password = 'FMSH8n';
$database= 'r00102430studentnumberdvds';

/*
$host = 'localhost';
$username = 'root';
$password = '';
$database= 'batman';
*/
$table = "titles";


?>