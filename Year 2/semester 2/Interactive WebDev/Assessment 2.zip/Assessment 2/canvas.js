
/*

  ____                                                               
 |  _ \                                                              
 | |_) |_   _                                                        
 |  _ <| | | |                                                       
 | |_) | |_| |                                                       
 |____/ \__, |_               _      _____       _          _      _ 
 |  __ \ __/ | |             | |    / ____|     | |        (_)    | |
 | |__) |___/| |__   ___ _ __| |_  | |  __  __ _| |__  _ __ _  ___| |
 |  _  // _ \| '_ \ / _ \ '__| __| | | |_ |/ _` | '_ \| '__| |/ _ \ |
 | | \ \ (_) | |_) |  __/ |  | |_  | |__| | (_| | |_) | |  | |  __/ |
 |_|  \_\___/|_.__/ \___|_|   \__|  \_____|\__,_|_.__/|_|  |_|\___|_|

*/










// Keep everything in anonymous function, called on window load.
if (window.addEventListener) {
    window.addEventListener('load', function () {
        var canvas, context, canvaso, contexto;

        // The active tool instance.
        var tool;
        var tool_default = 'pencil';

        function init() {
            // Find the canvas element.
            canvaso = document.getElementById('imageView');


            // Get the 2D canvas context

            context = canvaso.getContext('2d');

            // Activate the default tool.

                tool = new tools[tool_default]();
               
          

            // Attach the mousedown, mousemove and mouseup event listeners.


            document.getElementById("clear").addEventListener('click', newish, false);
			 document.getElementById("download").addEventListener('click', download, false);
            canvaso.addEventListener('mousedown', isKeyPressed, false);
            canvaso.addEventListener('mousedown', ev_canvas, false);
            canvaso.addEventListener('mousemove', ev_canvas, false);
            canvaso.addEventListener('mouseup', ev_canvas, false);
        }

        function isKeyPressed(event) {
            if (event.altKey == 1) {
                circle();
            } else {
                // alert("The shift key was NOT pressed!");
            }
        }

        function newish() {

            var canvas = document.getElementById('imageView');
            var context = canvas.getContext('2d');
            context.clearRect(0, 0, canvas.width, canvas.height);


        }

function download(){





var myElem = document.getElementById('badge');
if (myElem == null) 
{
alert('does not exist!');
}else {








var canvas = document.getElementById("middle"); 
var canvas2 = document.getElementById("imageView"); 

   // Button 
            var divo = document.createElement('div'); 
            divo.setAttribute("id", "badge"); 
            

			
			
			var img2 = document.createElement('img'); 
           img2.setAttribute("id", "boys"); 
		    img2.setAttribute("width", "600"); 
			 img2.setAttribute("height", "500"); 
			 
			 
			 
			 
			 
			 //menu and crap goes here 
		      var menudiv = document.createElement('div'); 
            menudiv.setAttribute("id", "menuDiv"); 
            
			//text and crap here 
			var Textdiv = document.createElement('div'); 
            Textdiv.setAttribute("id", "textStuff"); 
			
			 
			img2.src =canvas2.toDataURL();
			
			
			menudiv.appendChild(Textdiv);
				divo.appendChild(img2);
			divo.appendChild(menudiv);
            canvas.appendChild(divo); 
  


















}




}



function resize() 
           { 

           } 


var axesX;
var axesY;
        // The general-purpose event handler. This function just determines the mouse 
        // position relative to the canvas element.
        function ev_canvas(ev) {
		
             ev._x = ev.offsetX;
            ev._y = ev.offsetY;
axesX = ev._x ;
axesY = ev._y ;

            // Call the event handler of the tool.
            var func = tool[ev.type];
            if (func) {
                func(ev);
            }
        }

        // The event handler for any changes made to the tool selector.
        function ev_tool_change(ev) {
            if (tools[this.value]) {
                tool = new tools[this.value]();
            }
        }

        // This function draws the #imageTemp canvas on top of #imageView, after which 
        // #imageTemp is cleared. This function is called each time when the user 
        // completes a drawing operation.
        function img_update() {
            contexto.drawImage(canvaso, 0, 0);
        }

        
        
        
        function circle(ev) {

            var fill = document.getElementById('fill').value;
            var thickness = document.getElementById('width2').value;
            var colors = document.getElementById('colors').value;
            var canvas = document.getElementById('imageView');
            var context = canvas.getContext('2d');
            var radius = 70;

            context.beginPath();
            context.arc(axesX, axesY, radius, 0, 2 * Math.PI, false);
            context.fillStyle = fill;
            context.fill();
            context.lineWidth = 5;
            context.strokeStyle = colors;
            context.stroke();

        }


        // This object holds the implementation of each drawing tool.
        var tools = {};

        // The drawing pencil.
        tools.pencil = function () {
            var tool = this;
            this.started = false;

            // This is called when you start holding down the mouse button.
            // This starts the pencil drawing.
            this.mousedown = function (ev) {
                context.beginPath();
                context.moveTo(ev._x, ev._y);
                tool.started = true;
            };

            // This function is called every time you move the mouse. Obviously, it only 
            // draws if the tool.started state is set to true (when you are holding down 
            // the mouse button).
            this.mousemove = function (ev) {
                if (tool.started) {
                    var thickness = document.getElementById('width2').value;
                    var colors = document.getElementById('colors').value;
                    context.lineTo(ev._x, ev._y);
                    context.lineWidth = thickness;
                    context.strokeStyle = colors;
                    context.stroke();
                }
            };

            // This is called when you release the mouse button.
            this.mouseup = function (ev) {
                if (tool.started) {
                    tool.mousemove(ev);

                    tool.started = false;

                    img_update();
                }
            };
        };



        init();

    }, false);
}