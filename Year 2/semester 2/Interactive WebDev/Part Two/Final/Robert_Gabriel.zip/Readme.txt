Hi Gary,


The images are my own . the two logos.

The mona lisa was off google and has a water mark on it making it okay.

I didnt have enough time to tidy up the coe (less code). but have everything working.

I didnt have the search term saving working for the extra ones :) just the first one.


Everythign less is all working.