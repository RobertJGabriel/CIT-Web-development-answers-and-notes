/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package surgey;


import java.util.ArrayList;

public class Surgey {

private int surgeryId ;
private String surgeryAdd;
private ArrayList<Doctor> docList = new ArrayList<Doctor>();


	public static void main(String[] args) {
		System.out.print("sss");
	}



	private static void addDoctor() {

	}

	private static void updateDoctor() {

	}
	private static void saveSystemToFile() {

	}
	private static void restoreSystemFromFile() {

	}
	private static void login() {

	}
}
