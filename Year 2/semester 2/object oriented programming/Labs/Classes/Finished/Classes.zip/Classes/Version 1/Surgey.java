package test;

public class Surgey {



	public static void main(String[] args) {
		System.out.print("sss");
	}



	private static void addPatient() {

	}

	private static void addDoctor() {

	}

	private static void updatePatient() {

	}
	private static void addPatientsFile() {

	}
	private static void restorePatientsFile() {

	}
	private static void login() {

	}
}
