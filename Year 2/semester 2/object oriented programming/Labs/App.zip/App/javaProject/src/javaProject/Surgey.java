
package javaProject;

import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

import javax.swing.*;





public class Surgey extends JFrame implements ActionListener { 

	private int surgeryId ; 
	private String surgeryAdd; 
	private static ArrayList<Doctor> docList = new ArrayList<Doctor>(); 
	public static String holder;
	public String password;


	static JFrame frame;
	JFrame LoginFrame;
	JFrame addDoctorFrame;
	JMenuBar menuBar;
	JMenu docMenu;
	JMenu patentMenu;
	JPanel westPanel;
	JPanel centerPanel;
	JPanel southPanel;
	JList jl ;
	
	DefaultListModel<String> teste;
	public static void main(String[] args) { 
		Surgey Surgey = new Surgey();
		docList.add(new Doctor("rob", "sss"));
		docList.add(new Doctor("Kenneth", "sss"));
		docList.add(new Doctor("Batman", "sss"));
		docList.add(new Doctor("Ign", "sss"));

	}

	public  Surgey() { 
		login();
	}

	public void frame(){

		frame = new JFrame();
		frame.setSize(700, 500);
		frame.setTitle("Welcome Doctor");
		menuBar = new JMenuBar();
		docMenu = new JMenu("Doctor");
		patentMenu = new JMenu("Patent");


		docMenu.add(makeMenuItem("Restore"));
		docMenu.add(makeMenuItem("BackUp"));
		docMenu.add(makeMenuItem("Add Doctor"));
		docMenu.add(makeMenuItem("Log Out"));

		patentMenu.add(makeMenuItem("Add Patient"));
		patentMenu.add(makeMenuItem("Update Patrient "));
		patentMenu.add(makeMenuItem("Refresh List"));
		patentMenu.add(makeMenuItem("Remove Patient"));

		//Adding menu together.

		menuBar.add(docMenu);
		menuBar.add(patentMenu);


		//West Panel
		westPanel= new JPanel(); 
		westPanel.add(new JLabel("Doctors List"), BorderLayout.NORTH);
		westPanel.setPreferredSize(new Dimension (200, 500) );
		westPanel.setBackground(new Color(231, 76, 60));
		teste = new DefaultListModel<String>();

		teste.addElement("Name \t " + "Phone" );

		if (docList.get(1).getPatient().size() == 0){
			teste.addElement("No Patients");
		}else{

		}
		jl = new JList();
		jl.setModel(teste);
		jl.setPreferredSize(new Dimension (200, 500) );


		westPanel.add(jl,BorderLayout.NORTH);
		//Center Panel
		centerPanel = new JPanel(); 
		centerPanel.setPreferredSize(new Dimension (500, 400) );
		centerPanel.setBackground(new Color(52, 152, 219));

		//South Panel
		southPanel = new JPanel(); 
		southPanel.setPreferredSize(new Dimension (500, 50) );
		southPanel.setBackground(new Color(211, 84, 0));


		//Frame Layout
		frame.setLayout(new BorderLayout());
		frame.add(menuBar, BorderLayout.NORTH);
		frame.add(southPanel, BorderLayout.SOUTH);
		frame.add(westPanel, BorderLayout.WEST);	
		frame.add(centerPanel, BorderLayout.CENTER);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);  
		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {System.exit(0);}
		});
	}

	private void addList(){
		for(Patient s : docList.get(1).getPatient())  
		{  
			teste.addElement(s.getPName() + "\t" +  s.getPPhone());

		}

	}
	private  void addDoctor() { 

		//Conpunents 
		final JTextField name ;
		final JPasswordField passwords;
		JPanel middle;
		JPanel center;
		JLabel labelPass;
		JButton button;
		final JLabel label;

		//Label

		label = new JLabel();
		labelPass = new JLabel();
		label.setText("Enter Doctor Name");
		labelPass.setText("Enter Password");

		//Frame 
		addDoctorFrame = new JFrame();
		addDoctorFrame.setLayout(new BorderLayout());

		//Center
		center  = new JPanel();
		center.setBorder(BorderFactory.createEmptyBorder(10,10,10,10)); 

		//Input Field
		name =  new JTextField(10);
		name.setText("Doctor Name");

		//input Password
		passwords = new JPasswordField(10);
		passwords.setText("Password");

		//Button
		button =  new JButton();
		button.setText("Add Doctor");


		//Middle Container
		middle  = new JPanel();
		middle.setPreferredSize(new Dimension (200, 400) );
		middle.add(label,BorderLayout.NORTH);
		middle.add(name , BorderLayout.NORTH);
		middle.add(labelPass,BorderLayout.NORTH);
		middle.add(passwords, BorderLayout.NORTH);
		middle.add(button , BorderLayout.NORTH);

		center.add(middle);	

		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){

				String nameText = name.getText();
				String passwordText = passwords.getText();
				label.setText("Updated");
				docList.add(new Doctor(nameText,  passwordText));
				addDoctorFrame.setVisible(false);
				System.out.print("Add Docotor");
			}
		}
				);		
		addDoctorFrame.add(center);
		addDoctorFrame.setSize(300, 200);
		addDoctorFrame.setLocationRelativeTo(null);  
		addDoctorFrame.setTitle("Add Doctor");
		addDoctorFrame.setVisible(true);
		addDoctorFrame.setResizable(false);

	} 

	private static void updateDoctor() { 

	} 
	private static void saveSystemToFile() { 
		BufferedWriter bWriter = null;
		try{
			File file = new File("Database.txt");
			if(!file.exists()){
				file.createNewFile();
			}
			FileWriter fWriter = new FileWriter(file);
			bWriter = new BufferedWriter(fWriter);
			// Goes through each lecturer and writes its details
			for(int i=0; i<docList.size(); i++){
				bWriter.write(docList.get(i).getDoctorName().toString());
				bWriter.write(";");
				bWriter.write(docList.get(i).getDocPasswd().toString());
				bWriter.write(";");
				bWriter.write(docList.get(i).getDoctorId());
				bWriter.newLine();
			}
			System.out.print("Saved");
		}catch(IOException ex){
			ex.printStackTrace();
		}finally{
			try{
				// clears memory and closes writer
				if(bWriter != null){
					bWriter.flush();
					bWriter.close();
				}
			}catch(IOException ex){
				ex.printStackTrace();
			}
		}    
	} 


	private  void login()
	{
		JPanel center;
		JPanel middle;
		JLabel label;
		JLabel passLabel;
		final JTextField txt;
		final JPasswordField ps;
		JButton button;

		LoginFrame = new JFrame();
		LoginFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		LoginFrame.setLayout(new BorderLayout());
		LoginFrame.setLocationRelativeTo(null);  
		// UserName Label
		label = new JLabel();
		label.setText("UserName");

		// Doctors Name for input
		txt =new JTextField(10);
		txt.setText("Doctor Name");
		txt.requestFocus();
		// 	Password Label
		passLabel = new JLabel();
		passLabel.setText("Password  ");

		// Password Field	
		ps =new JPasswordField(10);
		ps.setText("*****");

		// Button
		button =new JButton();
		button.setText("Login");

		// Panel 
		middle = new JPanel();
		center = new JPanel();
		middle.setPreferredSize(new Dimension (160,400));
		center.setBorder(BorderFactory.createEmptyBorder(10,10,10,10)); 

		middle.add(label , BorderLayout.NORTH);
		middle.add(txt , BorderLayout.NORTH);
		middle.add(passLabel , BorderLayout.NORTH);
		middle.add(ps , BorderLayout.NORTH);
		middle.add(button , BorderLayout.NORTH);
		center.add(middle);

		// Adding parts to the frame
		LoginFrame.add(center);
		LoginFrame.setSize(300, 200);
		LoginFrame.setTitle("Login");
		LoginFrame.setVisible(true);
		LoginFrame.setResizable(false);

		//Button Listener
		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){

				String getTxt = txt.getText();
				String password = ps.getText();

				if(loginCheck(getTxt,password)== true){
					System.out.print(getTxt);
					//frame.setTitle( getTxt);
					txt.setText("");  
					ps.setText("");
					LoginFrame.setVisible(false);
					frame();

				}else {txt.setText("Wrong!!");}
			}
		}
				);	
	}





	public static boolean loginCheck(String name,String password) {

		int x =  docList.size();
		int i =0;
		for (i = 0 ; i <= x-1; i++){
			if (docList.get(i).getDoctorName().toString().equals(name) && (docList.get(i).getDocPasswd().toString().equals(password))){
				System.out.println("Login Ok");
				return true;
			}
		}
		System.out.println("Something is wrong");
		return false;
	} 

	private static void listPatients(){

		int x =  docList.size();
		for (int i =0;i <= x-1;i++) // Start of For Loop
		{
			System.out.print(docList.get(i).getDoctorName());// Gets Person Information
			System.out.print("\n----- patiets -----\n");
			System.out.print(docList.get(i).getPatient().get(x).toString());
			for (Patient s : 	docList.get(1).getPatient()) {  
				System.out.print(s.toString());  //Display Flims for actor
			}  
		}
		frame.repaint();
	}

	private static void restoreSystemFromFile() { 

	} 

	public void actionPerformed(ActionEvent e) {

		// Menu item actions
		String command = e.getActionCommand();

		if (command.equals("Log Out")) {
			frame.dispose();
			LoginFrame.setVisible(true);

		} else if (command.equals("Login")) {
			// Open menu item action


		}else if (command.equals("Add Patient")) {
			// Open menu item action
			Doctor.addPatient(null);
		}
		else if (command.equals("Update Patient")) {
			// Open menu item action
			Doctor.updatePatient();
		}

		else if (command.equals("Add Doctor")) {
			addDoctor();

		}	else if (command.equals("Refresh List")) {
			addList();

		}
		else if (command.equals("Restore")) {
			// Save menu item action
			System.out.println("Save menu item clicked");
		}
		else if (command.equals("BackUp")) {
			// Save menu item action
			saveSystemToFile() ;
		}
	}

	private JMenuItem makeMenuItem(String name) {
		JMenuItem m = new JMenuItem(name);
		m.addActionListener(this);
		return m;
	}
} 





