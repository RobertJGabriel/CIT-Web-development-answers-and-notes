- S3.php -

Amazon S3 PHP Class

Cloned from git://github.com/tpyo/amazon-s3-php-class.git
At commit 56770370c33a5310c5e07a9d22aef8c162f150ee

https://github.com/tpyo/amazon-s3-php-class
http://undesigned.org.za/2007/10/22/amazon-s3-php-class
