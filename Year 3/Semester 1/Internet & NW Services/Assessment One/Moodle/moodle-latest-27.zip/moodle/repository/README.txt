Repository API
==============

This directory contains all the interfaces and plugins for access to repositories.

   Specs:  http://docs.moodle.org/dev/Repository_API
   Track:  http://tracker.moodle.org/browse/MDL-13766


