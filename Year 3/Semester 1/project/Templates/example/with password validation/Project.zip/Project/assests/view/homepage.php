<?php


include('homepage/header.php');
include('homepage/index.php');
include('homepage/footer.php');



?>