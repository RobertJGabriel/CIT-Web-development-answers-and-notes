<?php

include('workout/header.php');
include('workout/index.php');
include('workout/footer.php');

?>
