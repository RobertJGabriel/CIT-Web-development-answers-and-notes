<?php

include('booking/header.php');
include('booking/index.php');
include('booking/footer.php');

?>
