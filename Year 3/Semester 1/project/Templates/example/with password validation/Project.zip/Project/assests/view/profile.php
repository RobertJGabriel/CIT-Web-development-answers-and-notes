<?php

include('profile/header.php');
include('profile/index.php');
include('profile/footer.php');

?>
