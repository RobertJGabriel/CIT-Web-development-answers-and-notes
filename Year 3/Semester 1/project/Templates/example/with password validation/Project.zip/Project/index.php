<?php 
	include_once("assests/controller/Controller.php");

	$controller = new Controller();
	$controller->invoke();

?>